Files
* daily_data_YYYY-MM-DD.rds -> Clean data at the state by day level. 
* weekly_data_YYYY-MM-DD.rds -> Clean data at the state by week level. 

2021-06-24 corresponds to the pre-registered analysis, 2021-09-12 is used in the multiverse analysis. 
